Orquestrador de Agentes (minimalista)
====================================

Descrição
--------
Exemplo minimalista em Python de um "Orquestrador de Agentes" com:

- Classe base Agent (persona, lifecycle)
- MessageBus in-memory com histórico e subscribe (pub/sub)
- Exemplos de agentes: RuleBasedAgent, EchoAgent, LLMAgent (placeholder)
- Script de demonstração `run_demo.py`

Como executar
-------------
Requisitos: Python 3.8+

No terminal (na pasta do projeto), você pode usar qualquer uma destas opções:

    python run_demo.py
    run_demo.cmd

No ambiente Windows desta máquina, o comando `python` não estava disponível no PATH, então foi adicionado um atalho em `run_demo.cmd` que usa o interpretador Python instalado em:

    C:\Users\bruno\AppData\Roaming\uv\python\cpython-3.14.6-windows-x86_64-none\python.exe

Arquitetura e próximos passos
---------------------------
- O MessageBus é central e em memória. Para ambientes distribuídos, troque por Redis Streams, Kafka ou um serviço HTTP.
- A classe LLMAgent é um placeholder; adicione integração com o provedor de LLM desejado (OpenAI, local LLM, etc.).
- Sugestões: persistência do histórico, controle de acesso entre agentes, métricas e monitoramento.
