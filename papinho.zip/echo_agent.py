from ..agent import Agent
from ..models import Message

class EchoAgent(Agent):
    """
    Agente que ecoa mensagens que mencionam seu nome.
    Útil para testes e demonstrações.
    """

    async def on_message(self, message: Message):
        if self.name.lower() in message.content.lower():
            self.publish(f"Echoing your message: {message.content}")
